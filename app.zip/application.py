import sys
from flask import Flask, request, json

application = Flask(__name__)


@application.route('/')
def hello():
    return 'Listening...'

@application.route('/veraWebsite',methods=['POST'])
def veraWebsite():
    sys.stdout.flush()
    if request.method == 'POST':
        print(request.json)
        return '',200
    else:
        abort(400)

if __name__ == '__main__':
    application.run(debug=True)
